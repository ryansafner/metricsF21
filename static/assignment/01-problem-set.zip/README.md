# Tips & Tricks

## Data Files

You can find the data files (for the second part) in the `data` folder. When importing from this folder, be sure to use the file path (including the `data/` folder) in the file name `read_csv` command, for example: `df <- read_csv("data/econfreedom.csv")`.

## Knitting to a PDF

If you wish to knit the `.Rmd` file to a `pdf` (it is currently set to `html`), you will need LaTeX. To avoid having to install a whole separate application on your computer, run the following code in R:

```{r}
install.packages("tinytex")
tinytex::install_tinytex()
```